@extends('layouts/app')
@section('content')
   <category-component></category-component>
   <router-view></router-view>
@endsection