@extends('layouts.app')
@section('content')
            <create-category></create-category>
@endsection
