<template>
  <v-parallax src="https://cdn.vuetifyjs.com/images/parallax/material.jpg" height="700">
   <v-layout
      align-center
      column
      justify-center
    >
      <h1 class="display-4 font-weight-thin mb-3">Aplikasi Pemesanan Tiket</h1>
      <h4 class="subheading headline">Real Time Single Page Application</h4>
    </v-layout>
  </v-parallax>
</template>
<script>
export default {

}
</script>

<style>

</style>
