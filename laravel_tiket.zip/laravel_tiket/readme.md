<p align="center"><img src="https://raw.githubusercontent.com/andihoerudin24/laravue_tiket/master/Capture.PNG"></p>

## About Laravue-tiket


Ticket booking application uses vue js, vuetify, sweat alert and SPA router system vue:

