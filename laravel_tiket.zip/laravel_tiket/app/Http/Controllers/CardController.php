<?php

namespace App\Http\Controllers;

class CardController extends Controller
{
    public function index()
    {
        return view('card');
    }
}
